import React, {useState} from 'react';

import {COLORS, getFontSize, getFontWeight, IMAGES} from '../../theme';
import {Text, TouchableOpacity, View} from 'react-native';
import {styles} from './styles';
import {APP_CONSTANTS} from '../../constants/Strings';
import FastImage from 'react-native-fast-image';
import PaginationDot from '../../components/PaginationDotsForImageSwiper';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import LinearGradient from 'react-native-linear-gradient';
import {useNavigation} from '@react-navigation/native';
import ArrowButton from '../ArrowImageButton';

const BannersList = [
  {
    title: APP_CONSTANTS.swiper_header1,
    description: APP_CONSTANTS.swiper_subHeading1,
    image: IMAGES.dummy,
    // width: 200,
    // height: 200,
  },
  {
    title: APP_CONSTANTS.swiper_header2,
    description: APP_CONSTANTS.swiper_subHeading2,
    image: IMAGES.ON_BOARDING2,
    // width: 254,
    // height: 236,
  },
  {
    title: APP_CONSTANTS.ON_BOARDING3_HEADER,
    description: APP_CONSTANTS.ON_BOARDING3_TEXT,
    subtext: APP_CONSTANTS.ON_BOARDING3_SUBTEXT,
    image: IMAGES.ON_BOARDING1,
    // width: 220,
    // height: 200,
  },
  {
    title: APP_CONSTANTS.ON_BOARDING4_HEADER,
    description: APP_CONSTANTS.ON_BOARDING4_TEXT,
    image: IMAGES.ON_BOARDING5,
    // width: 272,
    // height: 227,
  },
  // {
  //   title: APP_CONSTANTS.ON_BOARDING5_HEADER,
  //   description: APP_CONSTANTS.ON_BOARDING5_TEXT,
  //   image: IMAGES.ON_BOARDING3,
  //   label: APP_CONSTANTS.START_SHOPPING,
  //   // width: 180,
  //   // height: 140,
  // },
];

const HomePagerBannerView = () => {
  const [activePage, setActivePage] = useState(0);
  const navigation = useNavigation();

  const renderItem = ({item}) => {
    const {
      title,
      description,
      image,
      width = widthPercentageToDP('100%'),
      height = heightPercentageToDP('22%'),
    } = item ?? {};
    return (
      <View style={styles.itemContainer}>
        <FastImage
          style={[styles.image, {width, height}]}
          source={image}
          resizeMode={FastImage.resizeMode.cover}
        />
        <View style={styles.blackTransparencyContainer}>
          <LinearGradient
            colors={['rgba(0,0,0,0)', 'rgba(0,0,0,0.6)']}
            style={styles.blackTransparencySize}>
            <View
              style={{
                alignSelf: 'center',
                justifyContent: 'center',
                paddingHorizontal: widthPercentageToDP('2%'),
                position: 'absolute',
                top: heightPercentageToDP('5%'),
              }}>
              <Text numberOfLines={2} style={styles.header}>
                {title}
              </Text>
              <Text numberOfLines={1} style={styles.description}>
                {description}
              </Text>
            </View>
            <>
              <ArrowButton
                containerStyle={{left: 10}}
                disabled={false}
                height={heightPercentageToDP('18%')}
                image={IMAGES.LEFT_ARROW_SWIPER}
                onPress={() => {
                  if (activePage - 1 > 0) {
                    setActivePage(activePage - 1);
                  } else {
                    setActivePage(0);
                  }
                }}
              />
              <ArrowButton
                containerStyle={{right: 10}}
                disabled={false}
                height={heightPercentageToDP('18%')}
                image={IMAGES.RIGHT_ARROW_SWIPER}
                onPress={() => {
                  if (activePage + 1 < BannersList?.length) {
                    setActivePage(activePage + 1);
                  }
                }}
              />
            </>
          </LinearGradient>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.mainContainer}>
      {renderItem({item: BannersList[activePage]})}
      <TouchableOpacity onPress={() => navigation.navigate('ShopStack')}>
        <View style={styles.shopNowWrapper}>
          <Text style={styles.shopNowText}>SHOP NOW</Text>
        </View>
      </TouchableOpacity>
      <PaginationDot
        inActiveColor={COLORS.white_5}
        curPage={activePage}
        maxPage={BannersList?.length}
        containerStyle={styles.paginationContainer}
      />
    </View>
  );
};
export default HomePagerBannerView;
